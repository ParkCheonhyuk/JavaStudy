package quiz;

import java.util.Scanner;

public class D09_BruteForce {
  public static void main(String[] args) {
    Scanner sc = new Scanner(System.in);
    System.out.print("��й�ȣ�� ���̸� �Է��Ͻÿ�>>");
    int len = sc.nextInt();
     bruteForce(len);
  }

  public static void bruteForce(int len) {
    int[] password = new int[len];
    
    for (int i = 0; i < len; i++) {
      password[i] = 0;
    }
    find_password(len, password, 0);
  }
  
  private static String find_password(int len, int[] password, int position) {
    
   String assemble = "";
   
    char[] words = new char[] {
          '0','2','3','4','5','6','7','8','9',
          'A','B','C','D','E','F','G','H','I',
          'J','K','L','M','N','O','P','Q','R',
          'S','T','U','V','W','X','Y','Z','!',
          '@','#','$','%','^','&','*','(',')',
          '_','+','a','b','c','d','e','f','g',
          'h','i','j','k','l','m','n','o','p',
          'q','r','s','t','u','v','w','x','y',
          'z'
    };
     
    for (int i = 0; i < words.length+1; i++) {
      password[position] = i;
      if (position != len - 1) {
       String test = find_password(len, password, position + 1);
      } else if (position == len - 1) {
        for (int j = 0; j < len; j++) {
           switch (password[j] + 1) {
             case 1:
                assemble +=  "0";
                 break;
            case 2:
               assemble += "1";
                 break;
            case 3:
               assemble += "2";
                 break;
            case 4:
               assemble += "3";
                 break;
            case 5:
               assemble += "4";
                 break;
            case 6:
               assemble += "5";
                 break;
            case 7:
               assemble += "6";
                 break;
            case 8:
               assemble += "7";
                 break;
            case 9:
               assemble += "8";
                 break;
            case 10:
               assemble += "9";
                 break;
            case 11:
               assemble += "A";
               break;
            case 12:
               assemble += "B";
                 break;
            case 13:
               assemble += "C";
                 break;
            case 14:
               assemble += "D";
                 break;
            case 15:
               assemble += "E";
               break;
            case 16:
               assemble += "F";
                 break;
            case 17:
               assemble += "G";
                 break;
            case 18:
               assemble += "H";
                 break;
            case 19:
               assemble += "I";
                 break;
            case 20:
               assemble += "J";
                 break;
            case 21:
               assemble += "K";
                 break;
            case 22:
               assemble += "L";
                 break;
            case 23:
               assemble += "M";
                 break;
            case 24:
               assemble += "N";
                 break;
            case 25:
               assemble += "O";
                 break;
            case 26:
               assemble += "P";
                 break;
            case 27:
               assemble += "Q";
                 break;
            case 28:
               assemble += "R";
                 break;
            case 29:
               assemble += "S";
                 break;
            case 30:
               assemble += "T";
                 break;
            case 31:
               assemble += "U";
                 break;
            case 32:
               assemble += "V";
                 break;
            case 33:
               assemble += "W";
                 break;
            case 34:
               assemble += "X";
                 break;
            case 35:
               assemble += "Y";
               break;
            case 36:
               assemble += "Z";
                 break;
            case 37:
               assemble += "!";
                 break;
            case 38:
               assemble += "@";
                 break;
            case 39:
               assemble += "#";
                 break;
            case 40:
               assemble += "$";
                break;
            case 41:
               assemble += "%";
                 break;
            case 42:
               assemble += "^";
                 break;
            case 43:
               assemble += "&";
                 break;
            case 44:
               assemble += "*";
               break;  
            case 45:
               assemble += "(";
               break; 
            case 46:
               assemble += ")";
               break;
            case 47:
               assemble += "_";
               break;
            case 48:
               assemble += "+";
               break;
            case 49:
                assemble += "a";
                break;
            case 50:
                assemble += "b";
                break;
            case 51:
                assemble += "c";
                break;
            case 52:
                assemble += "d";
                break;
            case 53:
                assemble += "e";
                break;
            case 54:
                assemble += "f";
                break;
            case 55:
                assemble += "g";
                break;
            case 56:
                assemble += "h";
                break;
            case 57:
                assemble += "i";
                break;
            case 58:
                assemble += "j";
                break;
            case 59:
                assemble += "k";
                break;
            case 60:
                assemble += "l";
                break;
            case 61:
                assemble += "m";
                break;
            case 62:
                assemble += "n";
                break;
            case 63:
                assemble += "o";
                break;
            case 64:
                assemble += "p";
                break;
            case 65:
                assemble += "q";
                break;
            case 66:
                assemble += "r";
                break;
            case 67:
                assemble += "s";
                break;
            case 68:
                assemble += "t";
                break;
            case 69:
                assemble += "u";
                break;
            case 70:
                assemble += "v";
                break;
            case 71:
                assemble += "w";
                break;
            case 72:
                assemble += "x";
                break;
            case 73:
                assemble += "y";
                break;
            case 74:
                assemble += "z";
                break;
          }

        }
        System.out.println(assemble);
        assemble = "";
      }
    }
    return "";
  }
}